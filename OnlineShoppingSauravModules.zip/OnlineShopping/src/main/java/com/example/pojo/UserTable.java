package com.example.pojo;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the USER_TABLE database table.
 * 
 */
@Entity
@Table(name="USER_TABLE")
public class UserTable implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;



	@Override
	public String toString() {
		return "UserTable [uId=" + uId + ", uAddress=" + uAddress + ", uEmail=" + uEmail + ", uMobile=" + uMobile
				+ ", uName=" + uName + ", uPassword=" + uPassword + "]";
	}

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	@Column(name="U_ID")
	private int uId;

	@Column(name="U_ADDRESS")
	private String uAddress;

	@Column(name="U_EMAIL")
	private String uEmail;

	@Column(name="U_MOBILE")
	private int uMobile;

	@Column(name="U_NAME")
	private String uName;

	@Column(name="U_PASSWORD")
	private String uPassword;



	public UserTable() {
	}

	public int getUId() {
		return this.uId;
	}

	public void setUId(int uId) {
		this.uId = uId;
	}

	public String getUAddress() {
		return this.uAddress;
	}

	public void setUAddress(String uAddress) {
		this.uAddress = uAddress;
	}

	public String getUEmail() {
		return this.uEmail;
	}

	public void setUEmail(String uEmail) {
		this.uEmail = uEmail;
	}

	public int getUMobile() {
		return this.uMobile;
	}

	public void setUMobile(int uMobile) {
		this.uMobile = uMobile;
	}

	public String getUName() {
		return this.uName;
	}

	public void setUName(String uName) {
		this.uName = uName;
	}

	public String getUPassword() {
		return this.uPassword;
	}

	public void setUPassword(String uPassword) {
		this.uPassword = uPassword;
	}

	
}