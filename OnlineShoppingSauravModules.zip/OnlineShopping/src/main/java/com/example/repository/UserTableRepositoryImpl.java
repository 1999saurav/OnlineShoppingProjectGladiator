package com.example.repository;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.data.Reset;
import com.example.pojo.UserTable;

@Repository
public class UserTableRepositoryImpl extends BaseRepository implements UsersRepository {

	
	
	@Override
	public int getUserByEmailAndPassword(String email, String password) throws UserNotFoundException{
		// TODO Auto-generated method stub
		Query q = null;
		try
		{
			String query = "select uId from UserTable where uEmail=:x and uPassword=:y";
			q = (Query) this.entityManager.createQuery(query);
			q.setParameter("x", email);
			q.setParameter("y", password);
			System.out.println("Result is :"+q.getSingleResult());
		}
		catch(Exception e)
		{
			throw new UserNotFoundException("user not found");
		}
		return (int)q.getSingleResult();
	}
	
	//Update password by mail
	@Transactional
	@Override
 public int updatePasswordFromMail(Reset reset) throws UserNotFoundException
 {
	
		EntityManager entityManager = getEntityManager();
		String uEmail=reset.getEmail();
		Query query = entityManager.createQuery("select  u from UserTable u where u.uEmail = :vjob");
		query.setParameter("vjob",uEmail);
	
		UserTable existingUser= (UserTable)query.getSingleResult();
	
		int uId = existingUser.getUId();
		UserTable existingUser1 = this.entityManager.find(UserTable.class, uId);
		existingUser1.setUPassword(reset.getPassword());
		this.entityManager.merge(existingUser1);
		return 100;
			}
}