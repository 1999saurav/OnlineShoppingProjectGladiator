package com.example.repository;
import com.example.data.Reset;
import com.example.pojo.UserTable;
import org.springframework.stereotype.Repository;


@Repository
public interface UsersRepository {
	public int getUserByEmailAndPassword(String email, String password) throws UserNotFoundException;
	int updatePasswordFromMail(Reset reset) throws UserNotFoundException;
}