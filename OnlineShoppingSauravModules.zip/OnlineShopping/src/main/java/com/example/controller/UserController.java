package com.example.controller;


import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.CrossOrigin;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.data.Cart;
import com.example.data.Login;
import com.example.data.PlacedOrder;
import com.example.data.Reset;

import com.example.repository.UserNotFoundException;
import com.example.service.UserServiceImp;



@CrossOrigin
@RestController
@RequestMapping("/user")
public class UserController {
	
	@Autowired
	UserServiceImp userServiceImp;


	
	
	@PostMapping(path = "/login") 
	public int login(@RequestBody  Login login)
	{
		try {
			return this.userServiceImp.login(login);
		} catch (UserNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return -100;
		}
	}

	

	///Update password using email id
	
	@PutMapping(path = "/updateCustomer/reset")
	public int getUserUpdated(@RequestBody Reset reset) throws UserNotFoundException {
		System.out.println("getUserUpdated() ");
		int ok=userServiceImp.updatePasswordFromMailService(reset);
		if(ok==100)
		{
			return 100;
		}
		else {
			return -100;
		}
		
	}
	
	
	
	@GetMapping(path = "/getMyPlacedOrders/{uId}") // passed
	public List<PlacedOrder> sortProduct(@PathVariable String uId) {
		return this.userServiceImp.getMyPlacedOrders(Integer.parseInt(uId));
	}
	
	
	@PostMapping(path = "/placeOrder/{payType}") // passed
	public String placeOrder(@RequestBody List<Cart> carts, @PathVariable String payType) {
		boolean ok = this.userServiceImp.placeOrder(carts, payType);
		if (ok == true)
			return "Order Place Successfull";
		return "Order Place Failure";
	}
	@GetMapping(path = "/getMyCart/{uId}") //passed
	public List<Cart> getMyCart(@PathVariable String uId)
	{
		return this.userServiceImp.getCartValues(Integer.parseInt(uId));
	}
}
