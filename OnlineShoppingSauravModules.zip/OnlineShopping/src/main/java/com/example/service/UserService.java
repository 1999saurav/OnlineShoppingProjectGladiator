package com.example.service;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.data.Cart;
import com.example.data.Login;
import com.example.data.PlacedOrder;
import com.example.data.Reset;
import com.example.repository.UserNotFoundException;
@Repository
public interface UserService {

	int updatePasswordFromMailService(Reset reset) throws UserNotFoundException;
	public boolean placeOrder(List<Cart> carts, String payType);
	public List<PlacedOrder> getMyPlacedOrders(int uId);
	public int login(Login login) throws UserNotFoundException; 
	public List<Cart> getCartValues(int uId);//it is implemented by subhangi please keep only once
}
