package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.data.Cart;
import com.example.data.Login;
import com.example.data.PlacedOrder;
import com.example.data.Reset;
import com.example.repository.PlaceOrder;
import com.example.repository.UserNotFoundException;
import com.example.repository.UserTableRepositoryImpl;
@Repository
public class UserServiceImp implements UserService {
@Autowired
UserTableRepositoryImpl userRepoImp;
@Autowired
PlaceOrder placeOrder;


@Override
public int updatePasswordFromMailService(Reset reset) throws UserNotFoundException {
	// TODO Auto-generated method stub
	System.out.println("select all users service...");
	return userRepoImp.updatePasswordFromMail(reset);
}


@Override
public List<PlacedOrder> getMyPlacedOrders(int uId) {
	// TODO Auto-generated method stub
	return this.placeOrder.showPlacedOrders(uId);
}

@Override
public boolean placeOrder(List<Cart> carts, String payType) {
	// TODO Auto-generated method stub
	return this.placeOrder.placeOrder(carts, payType);
}


@Override
public int login(Login login) throws UserNotFoundException{
	int id = this.userRepoImp.getUserByEmailAndPassword(login.getEmail(),login.getPassword());
	return id;
}

@Override
public List<Cart> getCartValues(int uId) {
	// TODO Auto-generated method stub
	return this.placeOrder.getCartOfUser(uId);
}
}
