drop table admin_table cascade constraints;
drop table user_table cascade constraints;
drop table retailer_table cascade constraints;
drop table cart_table cascade constraints;
drop table order_table cascade constraints;
drop table order_detail_table cascade constraints;
drop table wishlist_table cascade constraints;
drop table payment_table cascade constraints;
drop table otp_table cascade constraints;
drop table product_table cascade constraints;


create table admin_table(
a_id number primary key,
a_email varchar2(20),
a_name varchar2(20),
a_password varchar2(20)
);

create table user_table(
u_id number primary key,
u_name varchar2(20),
u_email varchar2(20),
u_address varchar2(50),
u_mobile varchar2(10),
u_password varchar2(20)
);


create table retailer_table(
r_id number,
r_name varchar2(20),
r_email varchar2(30),
r_password varchar2(20),
r_mobile varchar2(12),
a_id number,
constraint retailer_pk primary key(r_id),
constraint retailer_fk foreign key (a_id) references admin_table(a_id) 
);

create table product_table(
p_id number primary key,
p_name varchar2(100),
p_image1 varchar2(100),
p_image2 varchar2(100),
p_description varchar2(100),
p_price float,
p_qty number,
p_category varchar2(100),
p_subcategory varchar2(100),
p_brand varchar2(100),
r_id number,
constraint product_rfk foreign key (r_id) references retailer_table (r_id)
);


create table payment_table(
pay_id number primary key,
pay_type varchar2(20));

create table order_table(
o_id number,
pay_id number,
u_id number,
constraint order_pk primary key (o_id),
constraint order_payfk foreign key (pay_id) references payment_table (pay_id),
constraint order_uidfk foreign key (u_id) references user_table (u_id));

create table order_detail_table(
od_id number primary key,
od_delivery_date date,
od_price float,
od_purchase_date date,
od_qty number,
o_id number,
p_id number,
CONSTRAINT fk_order FOREIGN KEY(o_id) REFERENCES order_table(o_id),
CONSTRAINT fk_product FOREIGN KEY(p_id) REFERENCES product_table(p_id));

create table otp_table(
otp_id number(10)  primary key,
otp_value number(10));

create table cart_table(
c_id number,
c_qty number,
p_id number,
u_id number,
constraint cart_pk primary key (c_id),
constraint cart_pidfk foreign key (p_id) references product_table (p_id),
constraint cart_uidfk foreign key (u_id) references user_table (u_id)
);

create table wishlist_table(
w_id  number(10)  primary key,
p_id number(10) ,
u_id number(10),
CONSTRAINT wish_ufk FOREIGN KEY(u_id) REFERENCES user_table(u_id),
CONSTRAINT wish_pfk FOREIGN KEY(p_id) REFERENCES product_table(p_id));
=========================================

insert into admin_table values(101,'lydia@gmail.com','lydia','lydia123');

insert into user_table values(301,'Scott','scott@gmail.com','BeaconHills Mumbai','9456872458','scm@0123');
insert into user_table values(302,'Annelle','annelle@gmail.com','Mayflower appartment Coimbatore','9026572398','pass@0099');
insert into user_table values(303,'Margareta','margareta@gmail.com','Shah street Hyderabad','9826577390','mag@1199');
insert into user_table values(304,'Augustus','augustus@gmail.com','OMG hall chennai','9878234390','aug@1490');
insert into user_table values(305,'Polly','polly@gmail.com','RK house Mahape','8877234390','Isen@098');
insert into user_table values(306,'Meghann','meglog@gmail.com','BeaconHills Mahape','9856234390','love@098');
insert into user_table values(307,'Rihanna','draken@gmail.com','Alumini Road Mekalaya','9458859410','jlove#100');
insert into user_table values(308,'Sergio','sergio@gmail.com','Village st Janmat','9567412890','password@1234');
insert into user_table values(309,'Mike','mike@gmail.com','Gandhi st Vathalakund','8025469721','mike#pass@1234');
insert into user_table values(310,'Donald','donald@gmail.com','Privet st Hyderabad','9015469721','donald@1234');
insert into user_table values(311,'Martin','martin@gmail.com','Garden road Hyderabad','8989469720','rose@223311');
insert into user_table values(312,'Lance','lance@gmail.com','Beach view Chennai','9898754210','vr35476@#');
insert into user_table values(313,'Tommy','tommy@gmail.com','Lake view Coimbatore','7845712420','tvvc##12');
insert into user_table values(314,'Malibu','mclub@gmail.com','Busy st Pondicherry','9091764210','mc78@46#');
insert into user_table values(315,'Brad','brad@gmail.com','Walking st Chennai','8975714210','life@sgood');
insert into user_table values(316,'Jack','jackm@gmail.com','4 Red hill Mahape','9997542102','good6@#');
insert into user_table values(317,'Maratha','marlake@gmail.com','Rock road Mahape','8298754210','rossi091>');
insert into user_table values(318,'Blake','blake@gmail.com','12 watchmaker st Chennai','8086754210','rickbad1_?');
insert into user_table values(319,'John','johnm@gmail.com','RDR st Gwalior','9212742100','vr3ker@#');
insert into user_table values(320,'Michael','mbr@gmail.com','3/1 Chandra nagar Palakkad','9608754210','kstate76@00');
insert into user_table values(321,'Athish','cka@gmail.com','Sundarapuram Coimbatore','9843554245','cka@0910');
insert into user_table values(322,'Jack','jfort@gmail.com','East Fort Thrissur','9873210580','kutty6#rk');
insert into user_table values(323,'Raju','rbhai@gmail.com','Andheri road Mumbai','9457821371','@123dutchman');
insert into user_table values(324,'Mano','mano@gmail.com','River road Kodaikanal','8796124830','palani6trip');
insert into user_table values(325,'Katara','katara12@gmail.com','West Fort Thrissur','8793210581','pooram123#');
insert into user_table values(326,'Revanth','revanth007@gmail.com','45 Whitefield Banglore','9003210580','white#shah12');
insert into user_table values(327,'Jane','imac@gmail.com','12 Vadivasal road Madurai','9994910580','metro@178');
insert into user_table values(328,'Brandon','got23@gmail.com','Winter fort Navi Mumbai','9894210580','nmbai#got-');
insert into user_table values(329,'Arjun','pushpa@gmail.com','23 Jubliee Hills Hyderabad','9025072760','siri->str12');
insert into user_table values(330,'Ajith','akumar@gmail.com','12 Ecr road Chennai','9994973012','t-1-a?');


insert into retailer_table values(201,'Genevieve','genevieve@gmail.com','Genevieve@123#',0223147858,101);

insert into retailer_table values(21,'Luciano','luciano@gmail.com','Luciano@123#',0223147859,101);

insert into retailer_table values(203,'Sharita','sharita@gmail.com','Sharita@123#',0223147863,101);

insert into retailer_table values(204,'Marietta','marietta@gmail.com','Marietta@123#',0223147869,101);

insert into retailer_table values(205,'Jack','jack@gmail.com','Jack@123#',0223147870,101);

insert into retailer_table values(206,'John','john@gmail.com','John@123#',0223147871,101);

insert into retailer_table values(207,'David','david@gmail.com','David@123#',0223147872,101);

insert into retailer_table values(208,'Richard','richard@gmail.com','Richard@123#',0223147873,101);

insert into retailer_table values(209,'James','james@gmail.com','James@123#',0223147874,101);

insert into retailer_table values(210,'Robert','robert@gmail.com','Robert@123#',02231478745,101);

insert into retailer_table values(21,'Joseph','joseph@gmail.com','Joseph@123#',02231478746,101);

insert into retailer_table values(212,'Thomas','thomas@gmail.com','Thomas@123#',02231478747,101);

insert into retailer_table values(213,'Charles','charles@gmail.com','Charles@123#',02242478701,101);

insert into retailer_table values(214,' Rodriguez','nancy@gmail.com','Nancy@123#',02242478702,101);

insert into retailer_table values(215,'Lisa','lisa@gmail.com','Lisa@123#',02242478703,101);

insert into retailer_table values(216,'Betty','betty@gmail.com','Betty@123#',02242478704,101);

insert into retailer_table values(217,'Carol','carol@gmail.com','Carol@123#',02242478705,101);

insert into retailer_table values(218,'Kathleen','kathleen@gmail.com','Kathleen@123#',02242478706,101);

insert into retailer_table values(219,'Stephen','stephen@gmail.com','Stephen@123#',02242478707,101);

insert into retailer_table values(220,'Nicholas','nicholas@gmail.com','Nicholas@123#',02242478708,101);

insert into retailer_table values(221,'Benjamin','benjamin@gmail.com','Benjamin@123#',02262574751,101);

insert into retailer_table values(222,'Eric','eric@gmail.com','Eric@123#',02262574761,101);

insert into retailer_table values(223,'Sophia','sophia@gmail.com','Sophia@123#',02262574781,101);

insert into retailer_table values(224,'Isabella','isabella@gmail.com','Isabella@123#',02262574891,101);

insert into retailer_table values(225,'Kayla','kayla@gmail.com','Kayla@123#',02262574111,101);

insert into retailer_table values(226,'Alice','alice@gmail.com','Alice@123#',02262574333,101);

insert into retailer_table values(227,'Megan','megan@gmail.com','Megan@123#',02262574444,101);

insert into retailer_table values(228,'Roger','roger@gmail.com','Roger@123#',02262574555,101);

insert into retailer_table values(229,'Lawrence','lawrence@gmail.com','Lawrence@123#',02262574666,101);

insert into retailer_table values(230,'Joe','joe@gmail.com','Joe@123#',02262574000,101);



INSERT INTO product_table VALUES (401,'Iphone 12','/assests/images/iphone12_1.jpeg','/assests/images/iphone12_2.jpeg','12 gb ram 512 gb Internal',100000,10,'Electronics','Mobile','Apple',201);

INSERT INTO product_table VALUES (402,'Samsung S2','/assests/images/Samsung_S2_1.jpeg','/assests/images/Samsung_S2_2.jpeg','8gb ram 128 gb internal',50000,4,'Electronics','Mobile','Samsung',21);

INSERT INTO product_table VALUES (403,'Samsung S11','/assests/images/Samsung_S11_1.jpeg','/assests/images/Samsung_S11_2.jpeg','6gb ram 128 gb internal',20000,3,'Electronics','Mobile','Samsung',203);

INSERT INTO product_table VALUES (404,'Iphone 10','/assests/images/iphone10_1.jpeg','/assests/images/iphone10_2.jpeg','8gb ram 64 gb internal',70000,2,'Electronics','Mobile','Apple',204);

INSERT INTO product_table VALUES (405,'Samsung S10','/assests/images/Samsung_S10_1.jpeg','/assests/images/Samsung_S10_2.jpeg','8gb ram 64 gb internal',70000,1,'Electronics','Mobile','Samsung',205);

INSERT INTO product_table VALUES (406,'Samsung S9','/assests/images/Samsung_S9_1.jpeg','/assests/images/Samsung_S9_2.jpeg','8gb ram 64 gb internal',70000,10,'Electronics','Mobile','Samsung',206);

INSERT INTO product_table VALUES (407,'Iphone 7','/assests/images/iphone7_1.jpeg','/assests/images/iphone7_2.jpeg','8gb ram 128gb internal',70000,6,'Electronics','Mobile','Apple',210);

INSERT INTO product_table VALUES (408,'Iphone 8','/assests/images/iphone8_1.jpeg','/assests/images/iphone8_2.jpeg','6gb ram 128gb internal',70000,8,'Electronics','Mobile','Apple',21);

INSERT INTO product_table VALUES (409,'Iphone 11','/assests/images/iphone11_1.jpeg','/assests/images/iphone11_2.jpeg','8gb ram',70000,51,'Electronics','Mobile','Apple',209);

INSERT INTO product_table VALUES (410,'HP  notebook Laptop','/assests/images/hp_notebook_laptop_1.jpeg','/assests/images/hp_notebook_laptop_2.jpeg','8gb ram i5processor',70000,50,'Electronics','Laptop','HP',215);

INSERT INTO product_table VALUES (411,'Lenevo Ideapad','/assests/images/lenevo_ideapad_1.jpeg','/assests/images/lenevo_ideapad_2.jpeg','16gb ram i5processor',100000,100,'Electronics','Laptop','Lenevo',217);

INSERT INTO product_table VALUES (412,'Macbook Air','/assests/images/macbook_air_1.jpeg','/assests/images/macbook_air_2.jpeg','8gb ram i7processor',50000,40,'Electronics','Laptop','Apple',216);

INSERT INTO product_table VALUES (413,'Macbook Mini','/assests/images/macbook_mini_1.jpeg','/assests/images/macbook_mini_2.jpeg','6gb ram i9processor',20000,30,'Electronics','Laptop','Apple',220);

INSERT INTO product_table VALUES (414,'Macbook Pro 21','/assests/images/macbook_pro_21_1.jpeg','/assests/images/macbook_pro_21_2.jpeg','8gb ram A14 chip',70000,20,'Electronics','Laptop','Apple',222);

INSERT INTO product_table VALUES (415,'Lenevo S3 Series','/assests/images/lenevo_S3_series_1.jpeg','/assests/images/lenevo_S3_series_2.jpeg','8gb ram i5processor',70000,10,'Electronics','Laptop','Lenevo',223);

INSERT INTO product_table VALUES (416,'Lenevo S5 Series','/assests/images/lenevo_S5_series_1.jpeg','/assests/images/lenevo_S5_series_2.jpeg','8gb ram i7processor',60000,10,'Electronics','Laptop','Lenevo',221);

INSERT INTO product_table VALUES (417,'Macbook pro 20','/assests/images/macbook_pro_20_1.jpeg','/assests/images/macbook_pro_20_2.jpeg','8gb ram i5processor',50000,60,'Electronics','Laptop','Apple',227);

INSERT INTO product_table VALUES (418,'Macbook Air 21','/assests/images/macbook_air_21_1.jpeg','/assests/images/macbook_air_21_2.jpeg','16gb ram i7processor',150000,80,'Electronics','Laptop','Apple',229);

INSERT INTO product_table VALUES (419,'Macbook Air M1','/assests/images/macbook_air_M1_1.jpeg','/assests/images/macbook_air_M1_2.jpeg','8gb ram M1 chip',100000,510,'Electronics','Laptop','Apple',208);

INSERT INTO product_table VALUES (420,'Harry Potter and the Philosophers Stone','/assests/images/HP_stone_1.jpeg','/assests/images/HP_stone_2.jpeg','Harry Potter and the Sorcererss Stone UK release: 26/06/97 US release 9/01/98',700,50,'Stationary','Book','Harry Potter Series',204);

INSERT INTO product_table VALUES (421,'Harry Potter and the Chamber of Secrets','/assests/images/HP_secrets_1.jpeg','/assests/images/HP_secrets_2.jpeg','UK release: 2/07/98 US release 6/02/99',1000,100,'Stationary','Book','Harry Potter Series',226);

INSERT INTO product_table VALUES (422,'Harry Potter and the Prisoner of Azkaban','/assests/images/HP_azkaban_1.jpeg','/assests/images/HP_azkaban_2.jpeg','(UK release: 8/07/99 US release 9/08/99)',500,40,'Stationary','Book','Harry Potter Series',228);

INSERT INTO product_table VALUES (423,'Harry Potter and the Goblet of Fire ','/assests/images/HP_goblet_1.jpeg','/assests/images/HP_goblet_2.jpeg',' (UK and US releases: 8/07/00)',200,30,'Stationary','Book','Harry Potter Series',227);

INSERT INTO product_table VALUES (424,'Harry Potter- the Order of the Phoenix ','/assests/images/HP_phoenix_1.jpeg','/assests/images/HP_phoenix_2.jpeg','(UK and US releases: 21/06/03)',700,20,'Stationary','Book','Harry Potter Series',221);

INSERT INTO product_table VALUES (425,'Harry Potte the Half-Blood Prince','/assests/images/HP_blood_1.jpeg','/assests/images/HP_blood_2.jpeg','(UK and US releases: 16/07/05)',700,10,'Stationary','Book','Harry Potter Series',201);

INSERT INTO product_table VALUES (426,'Harry Potter Deathly Hallows','/assests/images/HP_hallows_1.jpeg','/assests/images/HP_hallows_2.jpeg',' (UK and US releases: 21/07/07)',600,0,'Stationary','Book','Harry Potter Series',212);

INSERT INTO product_table VALUES (427,'Fantastic Beasts','/assests/images/beasts_1.jpeg','/assests/images/beasts_2.jpeg','(2001)',5000,60,'Stationary','Book','Harry Potter Series',213);

INSERT INTO product_table VALUES (428,'Quidditch Through the Ages','/assests/images/quidditch_1.jpeg','/assests/images/quidditch_2.jpeg',' (2001)',1500,80,'Stationary','Book','Harry Potter Series',216);

INSERT INTO product_table VALUES (429,'The Harry Potter Prequel ','/assests/images/prequel_1.jpeg','/assests/images/prequel_2.jpeg',' (2002)',100,50,'Stationary','Book','Harry Potter Series',217);

===============================================================================


insert into cart_table values (800,2,401,301);
insert into cart_table values (801,1,405,302);
insert into cart_table values (802,1,402,303);
insert into cart_table values (803,3,411,304);
insert into cart_table values (804,2,415,305);
insert into cart_table values (805,2,402,306);
insert into cart_table values (806,5,408,307);
insert into cart_table values (807,1,409,308);
insert into cart_table values (808,2,407,309);
insert into cart_table values (809,4,410,310);
insert into cart_table values (810,2,401,311);
insert into cart_table values (811,3,408,312);
insert into cart_table values (812,2,420,313);
insert into cart_table values (813,1,411,314);
insert into cart_table values (814,2,405,315);
insert into cart_table values (815,1,401,316);
insert into cart_table values (816,3,419,317);
insert into cart_table values (817,1,416,318);
insert into cart_table values (818,1,403,319);
insert into cart_table values (819,2,402,320);
insert into cart_table values (820,1,409,321);
insert into cart_table values (821,2,418,322);
insert into cart_table values (822,4,413,323);
insert into cart_table values (823,2,417,324);
insert into cart_table values (824,2,401,325);
insert into cart_table values (825,1,422,326);
insert into cart_table values (826,1,419,327);
insert into cart_table values (827,2,418,328);
insert into cart_table values (828,3,429,329);
insert into cart_table values (829,2,421,330);
insert into cart_table values (830,1,425,300);

-=====================================================
insert into payment_table values(501,'COD');
insert into payment_table values(502,'COD');
insert into payment_table values(503,'COD');
insert into payment_table values(504,'COD');
insert into payment_table values(505,'COD');
insert into payment_table values(506,'COD');
insert into payment_table values(507,'COD');
insert into payment_table values(508,'COD');
insert into payment_table values(509,'COD');
insert into payment_table values(510,'COD');
insert into payment_table values(511,'COD');
insert into payment_table values(512,'COD');
insert into payment_table values(513,'COD');
insert into payment_table values(514,'COD');
insert into payment_table values(515,'COD');
insert into payment_table values(516,'COD');
insert into payment_table values(517,'COD');
insert into payment_table values(518,'COD');
insert into payment_table values(519,'COD');
insert into payment_table values(520,'COD');
insert into payment_table values(521,'COD');
insert into payment_table values(522,'COD');
insert into payment_table values(523,'COD');
insert into payment_table values(524,'COD');
insert into payment_table values(525,'COD');
insert into payment_table values(526,'COD');
insert into payment_table values(527,'COD');
insert into payment_table values(528,'COD');
insert into payment_table values(529,'COD');
insert into payment_table values(530,'COD');
================================================

insert into order_table values (601,501,300);
insert into order_table values (602,502,301);
insert into order_table values (603,503,302);
insert into order_table values (604,504,302);
insert into order_table values (605,505,303);
insert into order_table values (606,506,304);
insert into order_table values (607,507,305);
insert into order_table values (608,508,305);
insert into order_table values (609,509,306);
insert into order_table values (610,510,307);
insert into order_table values (611,511,308);
insert into order_table values (612,512,309);
insert into order_table values (613,513,310);
insert into order_table values (614,514,310);
insert into order_table values (615,515,311);
insert into order_table values (616,516,312);
insert into order_table values (617,517,313);
insert into order_table values (618,518,314);
insert into order_table values (619,519,314);
insert into order_table values (620,520,315);

insert into order_detail_table values (201,'19-Feb-20',500,'10-Feb-20',1,601,401);
insert into order_detail_table values (202,'10-Mar-21',800,'27-Feb-21',2,602,403);
insert into order_detail_table values (203,'20-Apr-21',1500,'11-Mar-21',1,604,404);
insert into order_detail_table values (204,'30-May-21',800,'20-Apr-21',1,607,407);
insert into order_detail_table values (205,'19-Feb-20',500,'10-Feb-20',1,608,420);
insert into order_detail_table values (206,'24-Jun-21',900,'20-Jun-21',2,611,411);
insert into order_detail_table values (207,'30-Aug-20',1000,'20-Aug-20',1,620,422);
insert into order_detail_table values (208,'24-Sep-20',700,'12-Sep-20',1,619,421);
insert into order_detail_table values (209,'26-Jul-21',1000,'20-Jul-21',1,621,411);
insert into order_detail_table values (210,'19-Feb-20',800,'10-Feb-20',2,610,420);
insert into order_detail_table values (211,'21-Feb-20',1700,'11-Feb-20',2,621,419);
insert into order_detail_table values (212,'20-Feb-20',500,'10-Feb-20',1,609,419);
insert into order_detail_table values (213,'19-Mar-20',900,'10-Mar-20',1,618,418);
insert into order_detail_table values (214,'05-Jul-21',1000,'20-Jun-21',3,617,415);
insert into order_detail_table values (215,'09-Nov-20',6600,'01-Nov-20',3,622,422);
insert into order_detail_table values (216,'29-Jul-21',7000,'20-Jul-21',3,630,423);
insert into order_detail_table values (217,'01-Apr-21',500,'20-Mar-21',1,611,421);
insert into order_detail_table values (218,'02-Apr-21',900,'21-Mar-20',2,615,416);
insert into order_detail_table values (219,'03-May-21',1800,'22-Apr-21',2,618,418);
insert into order_detail_table values (220,'04-May-21',500,'23-Apr-21',1,611,410);
insert into order_detail_table values (221,'05-Jun-21',900,'24-May-21',1,613,429);
insert into order_detail_table values (222,'06-Jun-21',300,'25-May-21',1,630,414);
insert into order_detail_table values (223,'07-Jul-21',800,'26-Jun-21',2,622,418);
insert into order_detail_table values (224,'08-Jul-21',400,'26-Jun-21',1,612,412);
insert into order_detail_table values (225,'09-Aug-21',100,'27-Jul-21',1,626,429);
insert into order_detail_table values (226,'10-Apr-21',800,'28-Mar-21',2,614,413);
insert into order_detail_table values (227,'11-Feb-20',800,'01-Feb-20',1,616,416);
insert into order_detail_table values (228,'12-Mar-20',3300,'02-Mar-20',1,621,409);
insert into order_detail_table values (229,'30-Jan-21',700,'20-Jan-21',1,616,416);
insert into order_detail_table values (230,'27-Feb-20',7800,'20-Feb-20',3,615,417);



insert into otp_table values(900,123456);

insert into otp_table values(901,123566);

insert into otp_table values(902,123789);

insert into otp_table values(903,12753);

insert into otp_table values(904,178951);

insert into otp_table values(905,1258456);

insert into otp_table values(906,1895698798);

insert into otp_table values(907,123456465);

insert into otp_table values(908,12345613);

insert into otp_table values(909,1234568475);

insert into otp_table values(910,123456545);

insert into otp_table values(911,1234565454);

insert into otp_table values(912,1234565454);

insert into otp_table values(913,123456545);

insert into otp_table values(914,12345654);

insert into  wishlist_table values(701,400,300);
insert into  wishlist_table values(702,401,301);
insert into  wishlist_table values(703,402,302);
insert into  wishlist_table values(704,403,303);
insert into  wishlist_table values(705,404,304);
insert into  wishlist_table values(706,405,305);
insert into  wishlist_table values(707,406,306);
insert into  wishlist_table values(708,407,307);
insert into  wishlist_table values(709,408,308);
insert into  wishlist_table values(710,409,309);
insert into  wishlist_table values(711,410,310);
insert into  wishlist_table values(712,411,311);
insert into  wishlist_table values(713,412,312);
insert into  wishlist_table values(714,413,313);
insert into  wishlist_table values(715,414,314);
insert into  wishlist_table values(716,415,315);
insert into  wishlist_table values(717,416,316);
insert into  wishlist_table values(718,417,317);
insert into  wishlist_table values(719,418,318);
insert into  wishlist_table values(720,419,319);
insert into  wishlist_table values(721,420,320);
insert into  wishlist_table values(722,421,321);