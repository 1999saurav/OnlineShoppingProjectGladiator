export class Reset{
    email:String;
    password:String
}