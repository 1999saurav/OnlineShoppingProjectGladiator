import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UserLoginComponent } from './user-login/user-login.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CustomerServiceService } from './Service/customer-service.service';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { UserMyorderComponent } from './user-myorder/user-myorder.component';
import { HomeComponent } from './home/home.component';
import { UserPlaceOrderComponent } from './user-place-order/user-place-order.component';
@NgModule({
  declarations: [
    AppComponent,
    UserLoginComponent,
    ResetPasswordComponent,
    UserMyorderComponent,
    HomeComponent,
    UserPlaceOrderComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule

  ],
  providers: [CustomerServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
