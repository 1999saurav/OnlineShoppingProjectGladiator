export class PlacedOrder
{
    pName: string;
    pId : number;
	pImage : string;
	pBrand : string;
	pPrice : number;
	pOrderDate : string;
	pQty : number;
	pType : string;
}