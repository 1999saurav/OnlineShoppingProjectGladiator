import { HttpClient,HttpRequest,HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Reset } from '../reset-password/Reset';
import { Login } from '../user-login/Login';
import { PlacedOrder } from '../user-myorder/PlacedOrder';
import { Cart } from '../user-place-order/Cart';

@Injectable({
  providedIn: 'root'
})
export class CustomerServiceService {

  private _tempurl =  'http://localhost:8088/user/';
  private _url =      'http://localhost:8088/user/';


  constructor(private _http : HttpClient) { }

  login(login : Login) : Observable<number>
  {
    this._url = this._tempurl;
    this._url += 'login';
    return this._http.post<number>(this._url,login);
  }
  resetPassword(reset:Reset) : Observable<number>
  {
    this._url = this._tempurl;
    this._url += 'updateCustomer/reset';

    return this._http.put<number>(this._url,reset);
  }

 getMyPlacedOrders(uId: string) : Observable<PlacedOrder[]>
  {
    this._url = this._tempurl;
    this._url += 'getMyPlacedOrders/' + uId;
    return this._http.get<PlacedOrder[]>(this._url);
  }
  getMyCart(uId : string) : Observable<Cart[]>
  {
    this._url = this._tempurl;
    this._url += 'getMyCart/' + uId;
    return this._http.get<Cart[]>(this._url);
  }
  placeOrder(cart:Cart[],type:string)
  {
    this._url = this._tempurl;
    this._url += 'placeOrder' + '/' + type;
    return this._http.post(this._url,cart,{responseType:'text'});
  }
}
