import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { UserLoginComponent } from './user-login/user-login.component';
import { UserMyorderComponent } from './user-myorder/user-myorder.component';
import { UserPlaceOrderComponent } from './user-place-order/user-place-order.component';

const routes: Routes = [
  {path:'home',component:HomeComponent},
{path:'user-login',component:UserLoginComponent},

{path:'reset-password',component:ResetPasswordComponent},
{path:'user-myorder',component:UserMyorderComponent},
{path:'user-place-order',component:UserPlaceOrderComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
